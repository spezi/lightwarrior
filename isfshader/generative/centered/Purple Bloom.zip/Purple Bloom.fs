/*{
  "DESCRIPTION": "Purple Flower — validated ISF with color controls",
  "CATEGORIES": [
    "Generator"
  ],
  "CREDIT": "Lexxee",
  "ISFVSN": "2",
  "INPUTS": [
    {
      "NAME": "Speed",
      "TYPE": "float",
      "DEFAULT": 1.0,
      "MIN": -4.0,
      "MAX": 4.0
    },
    {
      "NAME": "PetalScale",
      "TYPE": "float",
      "DEFAULT": 1.0,
      "MIN": 0.1,
      "MAX": 4.0
    },
    {
      "NAME": "Zoom",
      "TYPE": "float",
      "DEFAULT": 1.0,
      "MIN": 0.2,
      "MAX": 3.0
    },
    {
      "NAME": "Brightness",
      "TYPE": "float",
      "DEFAULT": 1.0,
      "MIN": 0.0,
      "MAX": 3.0
    },
    {
      "NAME": "Contrast",
      "TYPE": "float",
      "DEFAULT": 1.0,
      "MIN": 0.0,
      "MAX": 3.0
    },
    {
      "NAME": "TintA",
      "TYPE": "color",
      "DEFAULT": [0.65, 0.20, 0.95, 1.0]
    },
    {
      "NAME": "TintB",
      "TYPE": "color",
      "DEFAULT": [0.20, 0.05, 0.35, 1.0]
    },
    {
      "NAME": "Background",
      "TYPE": "color",
      "DEFAULT": [0.0, 0.0, 0.0, 1.0]
    }
  ]
}*/

void main() {
    vec2 fragCoord = gl_FragCoord.xy;
    vec2 res = RENDERSIZE.xy;

    vec2 u = (fragCoord * 2.0 - res) / res.y;
    u /= Zoom;

    float c = length(u * 2.0) * PetalScale;
    float a = atan(u.y, u.x);

    vec2 p = vec2(c, a) * mat2(9.0, 0.0, 7.0, 3.0);

    float t = TIME * Speed;

    float cSafe = max(c, 0.0464);
    float denom = length(tan(p - t) / (cSafe * cSafe * cSafe) - c * c);
    vec4 x = sin(c + vec4(1.0, 2.0, 0.0, 0.0)) / max(denom, 0.0001);

    // tanh approximation for GLSL compatibility
    vec4 base = x / (1.0 + abs(x));

    vec3 flower = mix(TintB.rgb, TintA.rgb, clamp(base.rgb * 0.5 + 0.5, 0.0, 1.0));
    flower = (flower - 0.5) * Contrast + 0.5;
    flower *= Brightness;

    float mask = clamp(length(base.rgb), 0.0, 1.0);
    vec3 finalColor = mix(Background.rgb, flower, mask);

    gl_FragColor = vec4(clamp(finalColor, 0.0, 1.0), 1.0);
}
